package com.example.demo1.DBengine;

import java.sql.*;
import java.time.LocalDateTime;

public class EnrollmentDAO {
    final private String DBurl = DBConfig.getDbUrl();
    final private String DBuser= DBConfig.getUsername();
    final private String DBpassword=DBConfig.getPassword();
    //0为正常 1为异常
    public int enrollment(int applicantID,int activity_id){
        try {
            Connection connection = DriverManager.getConnection(DBurl, DBuser, DBpassword);
            Statement statement = connection.createStatement();

            // 构建SQL插入语句
            String insertQuery = "INSERT INTO enrollment (enroll_activity,enroll_user) VALUES ('" + activity_id + "', '" + applicantID +"')";

            // 执行插入操作
            statement.executeUpdate(insertQuery);

            // 关闭连接和语句
            statement.close();
            connection.close();

        } catch (SQLException e) {
            e.printStackTrace();
            return 1;
        }
        return 0;
    }
    //获取活动结束时间
    private boolean isCorrectTime(int activityID) {
        String query = "SELECT activity_date,activity_startTime, activity_duration FROM activity WHERE activity_id = " + activityID;

        try (Connection connection = DriverManager.getConnection(DBurl, DBuser, DBpassword);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            if (resultSet.next()) {

                int durationHours = resultSet.getInt("activity_duration");
                int activityStartTime = resultSet.getInt("activity_startTime");

                LocalDateTime temp=resultSet.getTimestamp("activity_date").toLocalDateTime();

                LocalDateTime actiStart=temp;
                actiStart=actiStart.plusHours(activityStartTime);

                LocalDateTime activityEndTime = temp.plusHours(durationHours);

                LocalDateTime currentTime = LocalDateTime.now();

                return currentTime.isBefore(activityEndTime)&&currentTime.isAfter(actiStart);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }
    // 0为正常，1为异常，2为校验失败，3为重复签到/签离
    public int regist(int applicantID, int activityID, LocalDateTime dateTime) {


        // 比较当前签到时间是否在活动时间范围内
        if (!isCorrectTime(activityID)) {
            // 签到时间不在活动时间范围内，校验失败
            return 2;
        } else {
            try (Connection connection = DriverManager.getConnection(DBurl, DBuser, DBpassword);
                 Statement statement = connection.createStatement()) {
                // 检查是否已经签到过
                String checkQuery = "SELECT COUNT(*) FROM enrollment WHERE enroll_user = " + applicantID + " AND enroll_activity = " + activityID+ " AND enroll_status <> '已报名'";
                ResultSet checkResult = statement.executeQuery(checkQuery);
                if (checkResult.next()) {
                    int count = checkResult.getInt(1);
                    if (count > 0) {
                        // 已经签到过，校验失败
                        return 3;
                    }
                }

                // 构建SQL更新语句
                String updateQuery = "UPDATE enrollment SET enroll_status = '已签到' WHERE enroll_user = " + applicantID + " AND enroll_activity = " + activityID;

                // 执行更新操作
                int rowsAffected = statement.executeUpdate(updateQuery);

                if (rowsAffected > 0) {
                    //签到成功
                    return 0;
                }

            } catch (SQLException e) {
                e.printStackTrace();
                return 1;
            }

            return 1;
        }
    }

    public int exit(int applicantID, int activityID, LocalDateTime dateTime) {


        // 比较当前时间（签离时间）是否在活动时间范围内
        if (!isCorrectTime(activityID)) {
            // 签离时间不在活动时间范围内，校验失败
            return 2;
        } else {
            try (Connection connection = DriverManager.getConnection(DBurl, DBuser, DBpassword);
                 Statement statement = connection.createStatement()) {

                // 检查是否已经签离过
                String checkQuery = "SELECT COUNT(*) FROM enrollment WHERE enroll_user = " + applicantID + " AND enroll_activity = "  + activityID+ " AND enroll_status <> '已签到'";
                ResultSet checkResult = statement.executeQuery(checkQuery);
                if (checkResult.next()) {
                    int count = checkResult.getInt(1);
                    if (count > 0) {
                        // 已经签离过，校验失败
                        return 3;
                    }
                }

                // 构建SQL更新语句
                String updateQuery = "UPDATE enrollment SET enroll_status = '已签离' WHERE enroll_user = " + applicantID + " AND enroll_activity = " + activityID;

                // 执行更新操作
                int rowsAffected = statement.executeUpdate(updateQuery);

                if (rowsAffected > 0) {
                    return 0;
                }

            } catch (SQLException e) {
                e.printStackTrace();
                return 1;
            }

            return 1;
        }
    }
    public void insertSummary(int studentId,String summary,int activityId){
        // 创建数据库连接
        try (Connection connection = DriverManager.getConnection(DBurl, DBuser, DBpassword)) {
            // 创建插入数据的PreparedStatement
            String sql = "update enrollment set enroll_summary= '"+summary+"' where enroll_user= "+studentId+" and enroll_activity="+activityId;
            PreparedStatement statement = connection.prepareStatement(sql);


            // 执行插入操作
            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("数据插入成功！");
            } else {
                System.out.println("数据插入失败！");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void insertVideo(int studentId,String video,int activityId){
        try (Connection connection = DriverManager.getConnection(DBurl, DBuser, DBpassword)) {
            // 创建插入数据的PreparedStatement
            String sql = "update enrollment set enroll_video= '"+video+"' where enroll_user= "+studentId+" and enroll_activity="+activityId;
            PreparedStatement statement = connection.prepareStatement(sql);


            // 执行插入操作
            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("数据插入成功！");
            } else {
                System.out.println("数据插入失败！");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
