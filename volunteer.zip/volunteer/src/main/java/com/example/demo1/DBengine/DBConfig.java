package com.example.demo1.DBengine;

public class DBConfig {

    private static final String dbUrl="jdbc:mysql://localhost:3306/volunteermanagement";
    private static final String username="root";
    private static final String password="123456";


    public static String getUsername() {
        return username;
    }

    public static String getPassword() {
        return password;
    }

    public static String getDbUrl() {
        return dbUrl;
    }
}
