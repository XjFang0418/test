package com.example.demo1.model;

public class User {
    private String name;
    private String password;
    private String schoolNumber;

    public String getName() {
        return name;
    }

    public String getPassword() {
        return password;
    }

    public String getSchoolNumber() {
        return schoolNumber;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setSchoolNumber(String schoolNumber) {
        this.schoolNumber = schoolNumber;
    }
}
