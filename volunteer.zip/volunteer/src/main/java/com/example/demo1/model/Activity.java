package com.example.demo1.model;

public class Activity {
    private String id;
    private String name;
    private String date;
    private String location;
    private String leader;
    private String status;

    public Activity(String id, String name, String date, String location, String leader, String status) {
        this.id = id;
        this.name = name;
        this.date = date;
        this.location = location;
        this.leader = leader;
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDate() {
        return date;
    }

    public String getLocation() {
        return location;
    }

    public String getLeader() {
        return leader;
    }

    public String getStatus() {
        return status;
    }

}
