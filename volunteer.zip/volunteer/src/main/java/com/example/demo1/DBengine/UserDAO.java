package com.example.demo1.DBengine;



import java.sql.*;

public class UserDAO {
    final private String DBurl = DBConfig.getDbUrl();
    final private String DBuser= DBConfig.getUsername();
    final private String DBpassword=DBConfig.getPassword();
   //0为登录成功，1为未查到学工号对应信息，2为密码错误
    public int login(String schoolID,String password){
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            connection = DriverManager.getConnection(DBurl, DBuser, DBpassword);
            statement = connection.createStatement();

            String query = "SELECT * FROM user WHERE user_schoolNumber = '" + schoolID + "' " ;
            resultSet = statement.executeQuery(query);
            if (resultSet.next()) {
                String storedpassword=resultSet.getString("user_password");
                boolean passwordMatch = PasswordUtils.verifyPassword(password, storedpassword);
                if (passwordMatch) {
                    // 密码匹配，进行登录操作
                    return 0;
                }
                return 2;
            } else {
                return 1;
            }
        } catch (SQLException e) {

            e.printStackTrace();
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (statement != null) {
                    statement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return 2;
    }

    public int register(String schoolID,String username,String password,String selectedRole){

            //0为插入成功，1为学号重复，2为密码长度不足（需要大于6），3为数据库插入出现错误。
            if(isSchoolIDDuplicate(schoolID)){
                return 1;
            }
            else if (password.length()<6) {
                return 2;
            }
            else{
                    try {
                        Connection connection = DriverManager.getConnection(DBurl, DBuser, DBpassword);
                        Statement statement = connection.createStatement();
                        String hashedPassword=PasswordUtils.hashPassword(password);
                        // 构建SQL插入语句
                        String insertQuery = "INSERT INTO user (user_name, user_password,user_schoolNumber,user_identity) VALUES ('" + username + "', '" + hashedPassword + "', '"+schoolID+"', '"+selectedRole+"')";

                        // 执行插入操作
                        statement.executeUpdate(insertQuery);

                        // 关闭连接和语句
                        statement.close();
                        connection.close();

                    } catch (SQLException e) {
                        e.printStackTrace();
                        return 3;
                    }
                }
          return 0;
    }

    public boolean isSchoolIDDuplicate(String schoolID){
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            connection = DriverManager.getConnection(DBurl, DBuser, DBpassword);
            statement = connection.createStatement();

            String query = "SELECT * FROM user WHERE user_schoolNumber = '" + schoolID+"'";
            resultSet = statement.executeQuery(query);

            if (resultSet.next()) {
                System.out.println("该用户已注册");
                return true;
                // 关闭当前登录界面
            } else {
                // 用户名或密码错误，弹出警告信息

                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (statement != null) {
                    statement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    public int schoolIDToID(String schoolID){
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            connection = DriverManager.getConnection(DBurl, DBuser, DBpassword);
            statement = connection.createStatement();

            String query = "SELECT * FROM user WHERE user_schoolNumber = '" + schoolID+"'";
            resultSet = statement.executeQuery(query);

            if (resultSet.next()) {
                return resultSet.getInt("user_id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (statement != null) {
                    statement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return -1;

    }
    public String schoolIDToIdentity(String schoolID){
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            connection = DriverManager.getConnection(DBurl, DBuser, DBpassword);
            statement = connection.createStatement();

            String query = "SELECT * FROM user WHERE user_schoolNumber = '" + schoolID+"'";
            resultSet = statement.executeQuery(query);

            if (resultSet.next()) {
                return resultSet.getString("user_identity");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (statement != null) {
                    statement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return null;

    }
}
