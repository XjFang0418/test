package com.example.demo1;
import com.example.demo1.model.User;
import com.example.demo1.view.*;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.kordamp.bootstrapfx.scene.layout.Panel;
import org.kordamp.bootstrapfx.BootstrapFX;

public class HelloApplication extends Application {
    public static User user;
    registerView registerView=new registerView();
    studentHomeView studentHomeView=new studentHomeView();
    mangerHomeView managerHomeView = new mangerHomeView();
    LoginView loginView=new LoginView();
    //面板容器
    static public VBox panelContainer;
    // 创建登录面板
    static Panel loginPanel;
    // 创建注册面板
    static Panel registerPanel;
    //创建学生主页面板
    static Panel studentHomePanel;
    //创建管理员主页面板
    static Panel managerHomePanel;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("志愿活动管理系统");
        // 创建面板容器
        loginPanel = loginView.createLoginPanel();
        registerPanel = registerView.createRegisterPanel();
        studentHomePanel=studentHomeView.createstudentHomePanel();
        managerHomePanel=managerHomeView.createManagerHomePanel();
        panelContainer = new VBox(20);
        panelContainer.setPadding(new Insets(20));
        panelContainer.getChildren().add(loginPanel);


        Scene scene = new Scene(panelContainer, 600, 500);
        scene.getStylesheets().add(BootstrapFX.bootstrapFXStylesheet());
        panelContainer.prefWidthProperty().bind(scene.widthProperty());
        panelContainer.prefHeightProperty().bind(scene.heightProperty());
        scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());


        primaryStage.setScene(scene);
        primaryStage.show();
    }
    static public void changeRegisterToLogin(){
        panelContainer.getChildren().remove(registerPanel);
        panelContainer.getChildren().add(loginPanel);
    }
    static public void changeLoginToHomepage(){
        panelContainer.getChildren().remove(loginPanel);
        panelContainer.getChildren().add(studentHomePanel);
    }
    static public void changeLoginToRegister(){
        panelContainer.getChildren().remove(loginPanel);
        panelContainer.getChildren().add(registerPanel);
    }
    static public void changeStudentHomepageToLogin(){
        panelContainer.getChildren().remove(studentHomePanel);
        panelContainer.getChildren().add(loginPanel);
    }
    static public void changeManagerHomepageToLogin(){
        panelContainer.getChildren().remove(managerHomePanel);
        panelContainer.getChildren().add(loginPanel);
    }
    static public void changeLoginToManagerHomePage(){
        panelContainer.getChildren().remove(loginPanel);
        panelContainer.getChildren().add(managerHomePanel);
    }

    public static void main(String[] args) {
        launch(args);
    }
}