package com.example.demo1.DBengine;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

public class PasswordUtils {
    private static final String HASH_ALGORITHM = "SHA-256";
    private static final int SALT_LENGTH = 16; // 盐值长度

    public static String hashPassword(String password) {
        try {
            SecureRandom random = new SecureRandom();
            byte[] salt = new byte[SALT_LENGTH];
            random.nextBytes(salt);

            MessageDigest md = MessageDigest.getInstance(HASH_ALGORITHM);
            md.update(salt);

            byte[] hashedPassword = md.digest(password.getBytes(StandardCharsets.UTF_8));

            // 将盐值和哈希后的密码拼接起来存储
            return bytesToHex(salt) + ":" + bytesToHex(hashedPassword);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static boolean verifyPassword(String password, String hashedPassword) {
        try {
            String[] parts = hashedPassword.split(":");
            byte[] salt = hexToBytes(parts[0]);
            byte[] expectedHash = hexToBytes(parts[1]);

            MessageDigest md = MessageDigest.getInstance(HASH_ALGORITHM);
            md.update(salt);

            byte[] actualHash = md.digest(password.getBytes(StandardCharsets.UTF_8));

            // 比较实际计算的哈希值与存储的哈希值是否一致
            return MessageDigest.isEqual(actualHash, expectedHash);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return false;
        }
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

    private static byte[] hexToBytes(String hex) {
        int length = hex.length();
        if (length % 2 != 0) {
            throw new IllegalArgumentException("Invalid hexadecimal string: " + hex);
        }

        byte[] bytes = new byte[length / 2];
        for (int i = 0; i < length; i += 2) {
            try {
                String byteString = hex.substring(i, i + 2);
                byte b = (byte) Integer.parseInt(byteString, 16);
                bytes[i / 2] = b;
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("Invalid hexadecimal string: " + hex, e);
            }
        }
        return bytes;
    }
}
