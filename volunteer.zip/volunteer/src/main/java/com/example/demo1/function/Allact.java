package com.example.demo1.function;

import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.media.*;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;
import com.example.demo1.DBengine.*;
import java.sql.*;

public class Allact {
    private String DBurl = DBConfig.getDbUrl();
    private String DBuser = DBConfig.getUsername();
    private String DBpassword = DBConfig.getPassword();

    public void showstudents(int activityId) {
        MangerDAO mangerDAO1 = new MangerDAO();
        Stage stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("报名学生列表");
        int row = 0;
        GridPane gridPane = new GridPane();
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setPadding(new Insets(10));

        String query = "SELECT user_id, user_name FROM enrollment INNER JOIN user ON enrollment.enroll_user = user.user_id WHERE enroll_activity = ?";
        try (Connection connection = DriverManager.getConnection(DBurl, DBuser, DBpassword);
                PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, activityId);
            ResultSet resultSet = statement.executeQuery();

            row = 0;
            Label idLabel0 = new Label("学生编号");
            Label nameLabel0 = new Label("学生姓名");
            Label pdfLabel = new Label("个人总结");
            Label videoLabel = new Label("活动视频");
            Label statet = new Label("签到状态");
            Label state = new Label("审核状态");
            gridPane.addRow(row, idLabel0, nameLabel0, videoLabel, pdfLabel, statet, state);
            row = 1;
            while (resultSet.next()) {
                int studentId = resultSet.getInt("user_id");
                String studentIdStr = String.valueOf(studentId);
                String studentName = resultSet.getString("user_name");
                Label idLabel = new Label(studentIdStr);
                Label nameLabel = new Label(studentName);

                String pdfPath = mangerDAO1.findpdf(activityId, studentId);
                String videoPath = mangerDAO1.findvideo(activityId, studentId);
                String iffin = mangerDAO1.findfin(activityId, studentId);
                System.out.println(iffin);
                Button viewVideoButton = new Button("查看视频");
                Button viewPdfButton = new Button("查看总结");
                Button toFinButton = new Button("审核通过");
                Label stateLabel = new Label(mangerDAO1.findstate(activityId, studentId));
                Button outFinButton = new Button("撤销通过");
                Label viewLabel1 = new Label("未提交");
                Label viewLabel2 = new Label("未提交");

                gridPane.addRow(row, idLabel, nameLabel,
                        pdfPath == null || pdfPath.isEmpty() ? viewLabel1 : viewVideoButton,
                        videoPath == null || videoPath.isEmpty() ? viewLabel2 : viewPdfButton, stateLabel,
                        iffin.equals("已通过") ? outFinButton : toFinButton);

                viewVideoButton.setOnAction(e -> viewVideo(activityId, studentId));
                viewPdfButton.setOnAction(e -> viewPDF(activityId, studentId));
                toFinButton.setOnAction(e -> {
                    if (toFinButton.getText().equals("审核通过")) {
                        mangerDAO1.updateFinStatus(activityId, studentId, "已通过");
                        toFinButton.setText("撤销通过");
                    } else {
                        mangerDAO1.updateFinStatus(activityId, studentId, "未通过");
                        toFinButton.setText("审核通过");
                    }

                });
                outFinButton.setOnAction(e -> {
                    if (outFinButton.getText().equals("审核通过")) {
                        mangerDAO1.updateFinStatus(activityId, studentId, "已通过");
                        outFinButton.setText("撤销通过");
                    } else {
                        mangerDAO1.updateFinStatus(activityId, studentId, "未通过");
                        outFinButton.setText("审核通过");
                    }
                });
                row++;
            }
        } catch (

        SQLException e) {
            e.printStackTrace();
        }

        // 计算列表的高度，并将其应用于窗口和场景
        double windowHeight = (row + 1) * (gridPane.getVgap() + 30) + 40; // 每行高度为30，加上间距和边距的高度
        stage.setHeight(windowHeight);
        Scene scene = new Scene(gridPane);
        stage.setScene(scene);
        stage.showAndWait();
    }

    public static void viewPDF(int activityId, int studentId) {
        Stage primaryStage = new Stage();
        WebView webView = new WebView();

        // 获取 WebView 的 Web 引擎对象
        WebEngine webEngine = webView.getEngine();
        System.out.println("http://127.0.0.1:8000/webtest/" + activityId + ".html");
        // 加载 PDF 文件
        if (studentId == 0)
            webEngine.load("http://127.0.0.1:8000/webtest/" + activityId + ".html");
        else
            webEngine.load("http://127.0.0.1:8000/webtest/" + activityId + "-" + studentId + ".html");
        // 创建一个 StackPane 并将 WebView 放入其中
        StackPane root = new StackPane();
        root.getChildren().add(webView);

        // 创建一个 Scene 并将 StackPane 放入其中
        Scene scene = new Scene(root);

        // 设置舞台的场景
        primaryStage.setScene(scene);

        // 监听 Scene 的宽度和高度变化，使 WebView 大小跟随窗口变化
        scene.widthProperty().addListener((observable, oldValue, newValue) -> {
            webView.setPrefWidth((double) newValue);
        });

        scene.heightProperty().addListener((observable, oldValue, newValue) -> {
            webView.setPrefHeight((double) newValue);
        });

        // 显示舞台
        primaryStage.show();
    }

    private void viewVideo(int activityId, int studentId) {
        String videoPath = System.getProperty("user.dir")+"\\src\\main\\resources\\video\\" + activityId + "-"
                + studentId + ".mp4";
        Media media = new Media(videoPath);
        MediaPlayer mediaPlayer = new MediaPlayer(media);

        // 创建媒体视图
        MediaView mediaView = new MediaView(mediaPlayer);

        // 创建舞台并设置场景
        Stage videoStage = new Stage(StageStyle.DECORATED);
        videoStage.setTitle("视频播放");
        videoStage.setScene(new Scene(new BorderPane(mediaView), 600, 400));

        // 创建控制按钮和进度条
        Button playButton = new Button("播放");
        Button pauseButton = new Button("暂停");
        Slider slider = new Slider();
        HBox controlsBox = new HBox(10, playButton, pauseButton, slider);
        controlsBox.setPadding(new Insets(10));

        // 监听舞台大小变化
        videoStage.widthProperty().addListener((observable, oldValue, newValue) -> {
            mediaView.setFitWidth(newValue.doubleValue() - 100);
        });
        videoStage.heightProperty().addListener((observable, oldValue, newValue) -> {
            mediaView.setFitHeight(newValue.doubleValue() - 100);
        });
        mediaPlayer.statusProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue == MediaPlayer.Status.READY) {
                // 设置进度条的最大值为视频的持续时间
                double duration = mediaPlayer.getTotalDuration().toSeconds();
                slider.setMax(duration);
            }
        });
        // 监听媒体播放状态变化
        mediaPlayer.statusProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue == MediaPlayer.Status.PLAYING) {
                playButton.setDisable(true);
                pauseButton.setDisable(false);
            } else {
                playButton.setDisable(false);
                pauseButton.setDisable(true);
            }
        });

        // 监听进度条值变化
        slider.valueProperty().addListener((observable, oldValue, newValue) -> {
            if (slider.isValueChanging()) {
                mediaPlayer.seek(Duration.seconds(newValue.doubleValue()));
            }
        });

        // 播放按钮点击事件
        playButton.setOnAction(event -> mediaPlayer.play());

        // 暂停按钮点击事件
        pauseButton.setOnAction(event -> mediaPlayer.pause());

        // 媒体播放进度监听
        mediaPlayer.currentTimeProperty().addListener((observable, oldValue, newValue) -> {
            if (!slider.isValueChanging()) {
                slider.setValue(newValue.toSeconds());
            }
        });

        // 创建BorderPane并设置媒体视图
        BorderPane root = new BorderPane();
        root.setCenter(mediaView);

        // 将控制按钮和进度条添加到底部
        root.setBottom(controlsBox);

        // 创建场景
        Scene scene = new Scene(root, 600, 400);

        // 设置舞台标题和场景
        videoStage.setTitle("视频播放");
        videoStage.setScene(scene);

        // 显示舞台并播放视频
        videoStage.show();
        mediaPlayer.play();

    }

}
