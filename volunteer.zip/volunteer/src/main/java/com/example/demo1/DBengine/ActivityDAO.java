package com.example.demo1.DBengine;
import com.example.demo1.DBengine.*;
import java.sql.*;
import java.time.LocalDate;

public class ActivityDAO {

    private String DBurl = DBConfig.getDbUrl();
    private String DBuser= DBConfig.getUsername();
    private String DBpassword=DBConfig.getPassword();
    //成功插入数据，返回0；结束时间小于开始时间，返回1；有必填项为空，返回2；sql操作失败，返回3
    public int publishActivity(String name,LocalDate date, int startTime, int endTime, String location, String applicant, String file){
        //
        int userid=searchUser(applicant);
        //如果用户学号不存在 或 查询失败
        if(userid<0){
            return 4;
        }
        if(endTime<startTime) {
            return 1;
        }
        else if(date==null||location==null||applicant==null||file==null){
            return 2;
        }
        else{
            try {
                Connection connection = DriverManager.getConnection(DBurl, DBuser, DBpassword);
                Statement statement = connection.createStatement();

                // 构建SQL插入语句
                String insertQuery = "INSERT INTO activity (activity_name, activity_date,activity_startTime,activity_duration,activity_applicat,activity_place,activity_file) VALUES ('" +name+ "', '"+ date + "', '" + startTime + "', '"+(endTime-startTime)+"', '"+userid+"', '"+location+"', '"+file+"')";

                // 执行插入操作
                statement.executeUpdate(insertQuery);

                // 关闭连接和语句
                statement.close();
                connection.close();

            } catch (SQLException e) {
                e.printStackTrace();
                return 3;
            }
        }
        return 0;
    }

    private int searchUser(String applicantSchoolID){
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            connection = DriverManager.getConnection(DBurl, DBuser, DBpassword);
            statement = connection.createStatement();

            String query = "SELECT * FROM user WHERE user_schoolNumber = '" + applicantSchoolID+"'";
            resultSet = statement.executeQuery(query);

            if (resultSet.next()) {
                return resultSet.getInt("user_id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (statement != null) {
                    statement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return -1;
    }

    public int updateActivity(int activityID, String newName, LocalDate newDate, int newStartTime, int newEndTime, String newLocation, String newApplicant, String file) {
        String query = "UPDATE activity SET activity_name = ?, activity_date = ?, activity_startTime = ?, activity_duration = ?, activity_place = ?, activity_applicat = ?, activity_file = ? WHERE activity_id = ?";
        try (Connection connection = DriverManager.getConnection(DBurl, DBuser, DBpassword);
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, newName);
            statement.setDate(2, Date.valueOf(newDate));
            statement.setInt(3, newStartTime);
            statement.setInt(4, newEndTime-newStartTime);
            statement.setString(5, newLocation);
            statement.setString(6, newApplicant);
            statement.setString(7, file);
            statement.setInt(8, activityID);

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            // 处理异常
            return 1;
        }
        return 0;
    }

    public int updateActivityStatus(int activityID, String status) {
        String query = "UPDATE activity SET activity_status = ? WHERE activity_id = ?";
        try (Connection connection = DriverManager.getConnection(DBurl, DBuser, DBpassword);
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, status);
            statement.setInt(2, activityID);

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            // 处理异常
            return 1;
        }
        return 0;
    }


}
