package com.example.demo1.view;

import com.example.demo1.DBengine.*;
import com.example.demo1.HelloApplication;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.kordamp.bootstrapfx.scene.layout.Panel;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class studentHomeView {
    private static final String PROJECT_FOLDER = System.getProperty("user.dir")+"\\src\\main\\resources";
    private String DBurl = DBConfig.getDbUrl();
    private String DBuser= DBConfig.getUsername();
    private String DBpassword=DBConfig.getPassword();
    private ActivityDAO activityDAO=new ActivityDAO();
    private UserDAO userDAO=new UserDAO();
    private EnrollmentDAO enrollmentDAO=new EnrollmentDAO();
    private Panel panel;

    private BorderPane root;
    private File selectedFile;
    private TextField fileTextField;
    public Panel createstudentHomePanel(){
        panel = new Panel("学生主页");
        panel.getStyleClass().add("panel-info");


        VBox sidebar = new VBox();
        sidebar.getStyleClass().add("menu-bar");
        sidebar.setPrefHeight(500);



        Button publishActivityButton = new Button("发布活动");
        publishActivityButton.getStyleClass().setAll("sidebar-button");
        publishActivityButton.setOnAction(e -> switchToPublishActivityPage());

        Button activityDisplayButton = new Button("所有活动");
        activityDisplayButton.getStyleClass().setAll("sidebar-button");
        activityDisplayButton.setOnAction(e -> switchToActivitiesPage());


        Button myActivityButton = new Button("我参与的活动");
        myActivityButton.getStyleClass().setAll("sidebar-button");
        myActivityButton.setOnAction(actionEvent -> switchToMyActivitiesPage());


        Button organizedActivityButton = new Button("我发布的活动");
        organizedActivityButton.getStyleClass().setAll("sidebar-button");
        organizedActivityButton.setOnAction(actionEvent -> switchToOrganizedActivityPage());

        Button finishedActivityButton = new Button("活动总结");
        finishedActivityButton.getStyleClass().setAll("sidebar-button");
        finishedActivityButton.setOnAction(actionEvent -> switchToFinishedActivityPage());

        Button logoutButton = new Button("注销");
        logoutButton.getStyleClass().setAll("sidebar-logout-button");
        logoutButton.setOnAction(actionEvent -> {
            HelloApplication.changeStudentHomepageToLogin();
        });



        sidebar.getChildren().addAll(activityDisplayButton,publishActivityButton, myActivityButton, organizedActivityButton, finishedActivityButton,logoutButton);

        root = new BorderPane();
        root.setLeft(sidebar);
        panel.setBody(root);
        switchToActivitiesPage();
        return panel;
    }

    private void switchToOrganizedActivityPage() {
        FlowPane page5Content = new FlowPane();
        int UserID=userDAO.schoolIDToID(HelloApplication.user.getSchoolNumber());
        page5Content.setPadding(new Insets(10));
        String query="SELECT activity_status,activity_id,activity_date,activity_name,activity_startTime,activity_duration,activity_place FROM activity where activity_applicat="+UserID;
        try (Connection connection = DriverManager.getConnection(DBurl, DBuser, DBpassword);
             Statement statement = connection.createStatement();

             ResultSet resultSet = statement.executeQuery(query)
        ) {

            while (resultSet.next()) {
                String activityName = resultSet.getString("activity_name");
                String activityStartTime = resultSet.getString("activity_startTime");
                String activityDuration=resultSet.getString("activity_duration");
                String activityLocation = resultSet.getString("activity_place");
                String activityDate=resultSet.getString("activity_date");
                String activityStatus = resultSet.getString("activity_status");
                int activityId=resultSet.getInt("activity_id");

                // 创建活动卡片
                VBox activityCard = createOrganizedActivityCard(activityId,activityStatus,activityDate,activityName, activityStartTime, activityDuration,activityLocation);
                page5Content.getChildren().add(activityCard);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // 处理异常
        }


        root.setCenter(page5Content);
    }
    private VBox createOrganizedActivityCard(int id, String activityStatus, String date, String name, String startTime, String duration, String location) {
        VBox card = new VBox();
        card.setSpacing(10);
        card.setPadding(new Insets(10));
        card.getStyleClass().add("panel-success");
        card.setStyle("-fx-border-color: skyblue; -fx-border-width: 1px;");

        //待审批的nameStatusPane
        BorderPane nameStatusPane1 = new BorderPane();
        nameStatusPane1.getStyleClass().add("name-status-pane");

        Label nameLabel = new Label(name);
        nameLabel.getStyleClass().setAll("lbl", "lbl-default", "font-weight-bold");
        nameLabel.setStyle("-fx-font-size: 16px");

        Label statusLabel1 = new Label(activityStatus);
        statusLabel1.getStyleClass().setAll("lbl", "lbl-primary");
        BorderPane.setAlignment(statusLabel1, Pos.TOP_RIGHT);
        nameStatusPane1.setTop(nameLabel);
        nameStatusPane1.setRight(statusLabel1);

        //审批通过的nameStatusPane
        BorderPane nameStatusPane2 = new BorderPane();
        nameStatusPane2.getStyleClass().add("name-status-pane");

        Label statusLabel2 = new Label(activityStatus);
        statusLabel2.getStyleClass().setAll("lbl", "lbl-success");
        BorderPane.setAlignment(statusLabel2, Pos.TOP_RIGHT);
        nameStatusPane2.setTop(nameLabel);
        nameStatusPane2.setRight(statusLabel2);

        Label dateLabel = new Label("Date: " + date);
        Label startTimeLabel = new Label("StartTime: " + startTime + " o'clock");
        Label durationLabel = new Label("Duration: " + duration + " hours");
        Label locationLabel = new Label("Location: " + location);

        Button modifyPlanButton = new Button("修改");
        modifyPlanButton.getStyleClass().setAll("btn","btn-warning");
        modifyPlanButton.setOnAction(e -> {switchToModifyActivityPage(id); });


        if(activityStatus.equals("待审批")){
            card.getChildren().addAll(nameLabel, statusLabel1, dateLabel,startTimeLabel,durationLabel, locationLabel, modifyPlanButton);
        }
        else{
            card.getChildren().addAll(nameLabel, statusLabel2, dateLabel,startTimeLabel,durationLabel, locationLabel);
        }


        return card;
    }


    private void switchToModifyActivityPage(int activityID) {
        // 创建修改活动页面的布局
        VBox pageContent = new VBox();
        pageContent.getStyleClass().add("page-content");

        // 创建表单控件
        GridPane form = new GridPane();
        form.setHgap(10);
        form.setVgap(10);

        // 从数据库中获取活动的属性值
        String query = "SELECT activity_name, activity_date, activity_startTime, activity_duration, activity_place, activity_applicat, activity_file FROM activity WHERE activity_id = ?";
        try (Connection connection = DriverManager.getConnection(DBurl, DBuser, DBpassword);
             PreparedStatement statement = connection.prepareStatement(query)) {

            // 设置查询参数
            statement.setInt(1, activityID);

            // 执行查询并获取结果集
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                // 提取结果集中的属性值
                String name = resultSet.getString("activity_name");
                LocalDate date = resultSet.getDate("activity_date").toLocalDate();
                int startTime = resultSet.getInt("activity_startTime");
                int endTime = startTime + resultSet.getInt("activity_duration");
                String location = resultSet.getString("activity_place");
                int applicant = resultSet.getInt("activity_applicat");
                String file = resultSet.getString("activity_file");

                // 创建表单控件
                // 活动名称
                Label nameLabel = new Label("活动名称");
                TextField nameField = new TextField(name);
                form.addRow(0, nameLabel, nameField);

                // 活动日期
                Label dateLabel = new Label("活动日期:");
                DatePicker datePicker = new DatePicker(date);
                form.addRow(1, dateLabel, datePicker);

                // 开始时间
                Label startTimeLabel = new Label("开始时间:");
                ComboBox<Integer> startComboBox = new ComboBox<>();
                startComboBox.setItems(FXCollections.observableArrayList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24));
                startComboBox.setValue(startTime);
                form.addRow(2, startTimeLabel, startComboBox);

                // 结束时间
                Label endTimeLabel = new Label("结束时间:");
                ComboBox<Integer> endComboBox = new ComboBox<>();
                endComboBox.setItems(FXCollections.observableArrayList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24));
                endComboBox.setValue(endTime);
                form.addRow(3, endTimeLabel, endComboBox);

                // 活动地点
                Label locationLabel = new Label("活动地点:");
                TextField locationTextField = new TextField(location);
                form.addRow(4, locationLabel, locationTextField);

                // 申请人
                Label applicantLabel = new Label("申请人学号:");
                TextField applicantTextField = new TextField(String.valueOf(applicant));
                form.addRow(5, applicantLabel, applicantTextField);

                // 活动策划书
                Label fileLabel = new Label("活动策划书:");
                fileTextField = new TextField(file);
                Button uploadButton = new Button("上传");
                uploadButton.setOnAction(e -> selectFile());
                form.addRow(6, fileLabel, fileTextField, uploadButton);

                // 返回按钮
                Button backButton = new Button("返回");
                backButton.setOnAction(e -> {
                    switchToOrganizedActivityPage();
                });
                HBox backButtonBox = new HBox(backButton);
                backButtonBox.setAlignment(Pos.TOP_RIGHT);
                pageContent.getChildren().add(backButtonBox);

                // 提交按钮
                Button submitButton = new Button("提交");
                submitButton.setOnAction(e -> {
                    // 获取用户修改后的数据
                    String newName = nameField.getText();
                    LocalDate newDate = datePicker.getValue();
                    int newStartTime = startComboBox.getValue();
                    int newEndTime = endComboBox.getValue();
                    String newLocation = locationTextField.getText();
                    String newApplicant = applicantTextField.getText();
                    String newFile = fileTextField.getText();

                    // 执行更新操作
                    int success = activityDAO.updateActivity(activityID, newName, newDate, newStartTime, newEndTime, newLocation, newApplicant, newFile);

                    if (success == 0) {
                        // 更新成功
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("更新成功");
                        alert.setHeaderText(null);
                        alert.setContentText("活动信息已成功更新。");
                        alert.showAndWait();
                    } else {
                        // 更新失败
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("更新失败");
                        alert.setHeaderText(null);
                        alert.setContentText("活动信息更新失败，请重试。");
                        alert.showAndWait();
                    }
                });

                HBox buttonBox = new HBox(submitButton);
                buttonBox.setSpacing(10);

                form.setAlignment(Pos.CENTER);
                buttonBox.setAlignment(Pos.CENTER);

                pageContent.getChildren().addAll(form, buttonBox);
                pageContent.setAlignment(Pos.CENTER);

                // 在根布局中切换页面
                root.setCenter(pageContent);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // 处理异常
        }
    }



    private void switchToFinishedActivityPage(){
        FlowPane page4Content = new FlowPane();
        int UserID=userDAO.schoolIDToID(HelloApplication.user.getSchoolNumber());
        page4Content.setPadding(new Insets(10));
        String query="SELECT activity_status,activity_id,activity_date,activity_name,activity_startTime,activity_duration,activity_place FROM enrollment LEFT JOIN activity ON activity_id=enroll_activity where (activity_status='已结束') and enroll_user="+UserID;
        try (Connection connection = DriverManager.getConnection(DBurl, DBuser, DBpassword);
             Statement statement = connection.createStatement();

             ResultSet resultSet = statement.executeQuery(query)
        ) {

            while (resultSet.next()) {
                String activityName = resultSet.getString("activity_name");
                String activityStartTime = resultSet.getString("activity_startTime");
                String activityDuration=resultSet.getString("activity_duration");
                String activityLocation = resultSet.getString("activity_place");
                String activityDate=resultSet.getString("activity_date");
                String activityStatus = resultSet.getString("activity_status");
                int activityId=resultSet.getInt("activity_id");

                // 创建活动卡片
                VBox activityCard = createfinishedActivityCard(activityId,activityDate,activityName, activityStartTime, activityDuration,activityLocation);
                page4Content.getChildren().add(activityCard);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // 处理异常
        }

        root.setCenter(page4Content);
    }
    private void switchToPublishActivityPage(){
        // 创建发布活动页面的布局
        VBox page1Content = new VBox();
        page1Content.getStyleClass().add("page-content");
        //创建发布活动页面的内容
        GridPane form = new GridPane();
        form.setHgap(10);
        form.setVgap(10);
        Label nameLabel=new Label("活动名称");
        TextField nameField = new TextField();
        form.addRow(0,nameLabel,nameField);
        // 活动时间
        Label dateLabel = new Label("活动日期:");
        DatePicker datePicker = new DatePicker();
        form.addRow(1, dateLabel, datePicker);
        Label startTimeLabel = new Label("开始时间:");
        ComboBox<Integer> startComboBox = new ComboBox<>();
        startComboBox.setItems(FXCollections.observableArrayList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12,13,14,15,16,17,18,19,20,21,22,23,24));
        startComboBox.setPromptText("开始时间");

        Label endTimeLabel = new Label("结束时间:");
        ComboBox<Integer> endComboBox = new ComboBox<>();
        endComboBox.setItems(FXCollections.observableArrayList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12,13,14,15,16,17,18,19,20,21,22,23,24));
        endComboBox.setPromptText("结束时间");
        form.addRow(2,startTimeLabel,startComboBox);
        form.addRow(3,endTimeLabel,endComboBox);
        // 活动地点
        Label locationLabel = new Label("活动地点:");
        TextField locationTextField = new TextField();
        form.addRow(4, locationLabel, locationTextField);

        // 申请人
        Label applicantLabel = new Label("申请人学号:");
        TextField applicantTextField = new TextField();
        form.addRow(5, applicantLabel, applicantTextField);

        // 活动策划书
        Label fileLabel = new Label("活动策划书:");
        fileTextField = new TextField();
        //fileTextField.setDisable(true);
        Button uploadButton = new Button("上传");
        uploadButton.setOnAction(e -> selectFile());
        form.addRow(6, fileLabel, fileTextField, uploadButton);

        // 提交按钮
        Button submitButton = new Button("提交");

        submitButton.setOnAction(e -> {
            LocalDate date = datePicker.getValue();
            int startTime = startComboBox.getValue();
            int endTime = endComboBox.getValue();
            String location = locationTextField.getText();
            String applicant = applicantTextField.getText();
            String file = fileTextField.getText();
            String name=nameField.getText();
            submitForm(name,date,startTime,endTime,location,applicant,file);
        });

        HBox buttonBox = new HBox(submitButton);
        buttonBox.setSpacing(10);
        form.setAlignment(Pos.CENTER);
        buttonBox.setAlignment(Pos.CENTER);
        page1Content.getChildren().addAll(form, buttonBox);
        page1Content.setAlignment(Pos.CENTER);
        // 在根布局中切换页面
        root.setCenter(page1Content);
    }


    private void switchToActivitiesPage(){
        FlowPane page2Content = new FlowPane();

        page2Content.setPadding(new Insets(10));
        String query="SELECT activity_id,activity_name,activity_date,activity_startTime,activity_duration,activity_place FROM activity where activity_status='审批通过' or activity_status='进行中'";
        try (
                Connection connection = DriverManager.getConnection(DBurl, DBuser, DBpassword);
             Statement statement = connection.createStatement();

             ResultSet resultSet = statement.executeQuery(query)
        ) {

            while (resultSet.next()) {
                String activityName = resultSet.getString("activity_name");
                String activityStartTime = resultSet.getString("activity_startTime");
                String activityDuration=resultSet.getString("activity_duration");
                String activityLocation = resultSet.getString("activity_place");
                String activityDate=resultSet.getString("activity_date");
                int activityId=resultSet.getInt("activity_id");
                // 创建活动卡片
                VBox activityCard = createActivityCard(activityId,activityDate,activityName, activityStartTime, activityDuration,activityLocation);
                page2Content.getChildren().add(activityCard);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // 处理异常
        }

        root.setCenter(page2Content);

    }
    private void switchToMyActivitiesPage(){
        FlowPane page3Content = new FlowPane();
        int UserID=userDAO.schoolIDToID(HelloApplication.user.getSchoolNumber());
        page3Content.setPadding(new Insets(10));
        String query="SELECT activity_status,activity_id,activity_date,activity_name,activity_startTime,activity_duration,activity_place FROM enrollment LEFT JOIN activity ON activity_id=enroll_activity where enroll_user="+UserID;
        try (Connection connection = DriverManager.getConnection(DBurl, DBuser, DBpassword);
             Statement statement = connection.createStatement();

             ResultSet resultSet = statement.executeQuery(query)
        ) {

            while (resultSet.next()) {
                String activityName = resultSet.getString("activity_name");
                String activityStartTime = resultSet.getString("activity_startTime");
                String activityDuration=resultSet.getString("activity_duration");
                String activityLocation = resultSet.getString("activity_place");
                Timestamp activityDate=resultSet.getTimestamp("activity_date");
                String activityStatus = resultSet.getString("activity_status");
                int activityId=resultSet.getInt("activity_id");


                //计算时间
                LocalDateTime temp=activityDate.toLocalDateTime();

                LocalDateTime actiStart=temp;
                actiStart=actiStart.plusHours(Integer.parseInt(activityStartTime));

                LocalDateTime actiEnd=temp;
                actiEnd=actiEnd.plusHours(Integer.parseInt(activityDuration));

                LocalDateTime now=LocalDateTime.now();



                if(now.isAfter(actiStart)&&now.isBefore(actiEnd)&&!activityStatus.equals("进行中")){
                    activityStatus="进行中";
                    activityDAO.updateActivityStatus(activityId,activityStatus);
                }else if(now.isAfter(actiEnd)&&!activityStatus.equals("已结束")){
                    activityStatus="已结束";
                    activityDAO.updateActivityStatus(activityId,activityStatus);
                }

                String actiDateView= activityDate.toLocalDateTime().toString();

                // 创建活动卡片
                VBox activityCard = createmyActivityCard(activityId,activityStatus,actiDateView,activityName, activityStartTime, activityDuration,activityLocation);
                page3Content.getChildren().add(activityCard);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // 处理异常
        }

        root.setCenter(page3Content);
    }
    private VBox createmyActivityCard(int id,String activityStatus,String date,String name, String startTime, String duration,String location) {
        VBox card = new VBox();
        card.setSpacing(10);
        card.setPadding(new Insets(10));
        card.getStyleClass().add("panel-success");
        card.setStyle("-fx-border-color: skyblue; -fx-border-width: 1px;");

        Label nameLabel = new Label(name);
        nameLabel.getStyleClass().setAll("lbl","lbl-default","font-weight-bold");
        nameLabel.setStyle("-fx-font-size: 16px");
        Label dateLabel=new Label("Date:"+date);
        Label startTimeLabel = new Label("StartTime: " + startTime+" o'clock");
        Label durationLabel=new Label("Duration: "+duration+" hours");
        Label locationLabel = new Label("Location: " + location);

        Button statusButton1 = new Button("未开始");
        statusButton1.getStyleClass().setAll("btn","btn-default");
        statusButton1.setOnAction(e -> {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("活动未开始");
            alert.setHeaderText(null);
            alert.setContentText("活动将于"+date+" "+startTime+"点开始，请稍后查看");
            alert.showAndWait();
        });

        Button statusButton2 = new Button("已结束");
        statusButton2.getStyleClass().setAll("btn","btn-default");

        Button signUpButton = new Button("签到");
        signUpButton.getStyleClass().setAll("btn","btn-info");
        signUpButton.setOnAction(e -> registForActivity(LocalDateTime.now(),HelloApplication.user.getSchoolNumber(),id));
        Button exitButton = new Button("签离");
        exitButton.getStyleClass().setAll("btn","btn-danger");
        exitButton.setOnAction(e -> exitActivity(LocalDateTime.now(),HelloApplication.user.getSchoolNumber(),id));

        if(activityStatus.equals("进行中")){
            card.getChildren().addAll(nameLabel, dateLabel,startTimeLabel,durationLabel, locationLabel, signUpButton,exitButton);
        }
        else if(activityStatus.equals("已结束")){
            card.getChildren().addAll(nameLabel, dateLabel,startTimeLabel,durationLabel, locationLabel, statusButton2);
        }
        else{
            card.getChildren().addAll(nameLabel, dateLabel,startTimeLabel,durationLabel, locationLabel, statusButton1);
        }

        return card;
    }

    private void registForActivity(LocalDateTime dateTime,String schoolID,int activityID){
        int volunteerID=userDAO.schoolIDToID(schoolID);
        int result=enrollmentDAO.regist(volunteerID,activityID,dateTime);
        if(result==0){
            // 签到成功
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Sign In Success");
            alert.setHeaderText(null);
            alert.setContentText("Sign in successful.");
            alert.showAndWait();
        }
        if(result==2){
            // 签到时间不在活动时间范围内，校验失败
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Sign In Error");
            alert.setHeaderText(null);
            alert.setContentText("You can only sign in during the activity period.");
            alert.showAndWait();
        }
        if(result==3){
            // 已经签到过/未报名，校验失败
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Sign In Error");
            alert.setHeaderText(null);
            alert.setContentText("你的状态不对，暂不能签到！");
            alert.showAndWait();
        }
        else if(result==1){
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Sign In Error");
            alert.setHeaderText(null);
            alert.setContentText("Sign in failed, please try again.");
            alert.showAndWait();
        }
    }
    private void exitActivity(LocalDateTime dateTime,String schoolID,int activityID){

        int volunteerID=userDAO.schoolIDToID(schoolID);
        int result=enrollmentDAO.exit(volunteerID,activityID,dateTime);
        if(result==0){
            // 签离成功
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Sign Out Success");
            alert.setHeaderText(null);
            alert.setContentText("Sign out successful.");
            alert.showAndWait();
        }
        if(result==2){
            // 签离时间不在活动时间范围内，校验失败
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Sign Out Error");
            alert.setHeaderText(null);
            alert.setContentText("You can only sign out during the activity period.");
            alert.showAndWait();
        }
        if(result==3){
            // 已经签离过/未签到，校验失败
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Sign Out Error");
            alert.setHeaderText(null);
            alert.setContentText("你的状态不对，暂不能签离！");
            alert.showAndWait();
        }
        else if(result==1){
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Sign Out Error");
            alert.setHeaderText(null);
            alert.setContentText("Sign out failed, please try again.");
            alert.showAndWait();
        }
    }
    private VBox createActivityCard(int id,String date,String name, String startTime, String duration,String location) {
        VBox card = new VBox();
        card.setSpacing(10);
        card.setPadding(new Insets(10));
        card.getStyleClass().add("panel-success");
        card.setStyle("-fx-border-color: skyblue; -fx-border-width: 1px;");

        Label nameLabel = new Label(name);
        nameLabel.getStyleClass().setAll("lbl","lbl-default","font-weight-bold");
        nameLabel.setStyle("-fx-font-size: 16px");
        Label dateLabel=new Label("Date:"+date);
        Label startTimeLabel = new Label("StartTime: " + startTime+" o'clock");
        Label durationLabel=new Label("Duration: "+duration+" hours");
        Label locationLabel = new Label("Location: " + location);

        Button signUpButton = new Button("报名");
        signUpButton.getStyleClass().setAll("btn","btn-primary");
        signUpButton.setOnAction(e -> signUpForActivity(HelloApplication.user.getSchoolNumber(),id));

        card.getChildren().addAll(nameLabel, dateLabel,startTimeLabel,durationLabel, locationLabel, signUpButton);

        return card;
    }
    private void signUpForActivity(String applicantSchoolID,int activity_id) {
        int applicantID=userDAO.schoolIDToID(applicantSchoolID);

        int result=enrollmentDAO.enrollment(applicantID,activity_id);
        if(result==0){
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Sign up Success");
            alert.setHeaderText(null);
            alert.setContentText("You have successfully sign up this activity, please check it at 我的活动");
            alert.showAndWait();
        }
        else{
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Sign up Failed");
            alert.setHeaderText(null);
            alert.setContentText("You have failed sign up this activity");
            alert.showAndWait();
        }

    }

    private void selectFile() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("PDF Files", "*.pdf")
        );
        Stage stage = (Stage) panel.getScene().getWindow();
        selectedFile = fileChooser.showOpenDialog(stage);
        if (selectedFile != null) {
            String filePath = selectedFile.getAbsolutePath();
            fileTextField.setText(filePath);
        }
    }

    private void submitForm(String name,LocalDate date,int startTime,int endTime,String location,String applicant,String file) {
        int submitResult=activityDAO.publishActivity(name,date,startTime,endTime,location,applicant,file);
        if(submitResult==0){
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Submit Successful");
            alert.setHeaderText(null);
            alert.setContentText("Congratulations! You have successfully submit your activity.Please wait for the approvement");
            alert.showAndWait();
            if(alert.getResult().getText().equals("确定")) {
                switchToMyActivitiesPage();
            }
        }
        else if(submitResult==1){
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Submit Failed");
            alert.setHeaderText(null);
            alert.setContentText("The end time must be bigger than the start time!");
            alert.showAndWait();
        }
        else if(submitResult==2){
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Submit Failed");
            alert.setHeaderText(null);
            alert.setContentText("The mandatory field is blank, please check");
            alert.showAndWait();
        }
        else if(submitResult==4){
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Submit Failed");
            alert.setHeaderText(null);
            alert.setContentText("Your schoolID didn't exist,please check again");
            alert.showAndWait();
        }
        else{
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Submit Failed");
            alert.setHeaderText(null);
            alert.setContentText("Unknown sql error");
            alert.showAndWait();
        }

    }

    private VBox createfinishedActivityCard(int id,String date,String name, String startTime, String duration,String location) {
        VBox card = new VBox();
        card.setSpacing(10);
        card.setPadding(new Insets(10));
        card.getStyleClass().add("panel-success");
        card.setStyle("-fx-border-color: skyblue; -fx-border-width: 1px;");

        Label nameLabel = new Label(name);
        nameLabel.getStyleClass().setAll("lbl","lbl-default","font-weight-bold");
        nameLabel.setStyle("-fx-font-size: 16px");
        Label dateLabel=new Label("Date:"+date);
        Label startTimeLabel = new Label("StartTime: " + startTime+" o'clock");
        Label durationLabel=new Label("Duration: "+duration+" hours");
        Label locationLabel = new Label("Location: " + location);


        Button signUpButton = new Button("上传活动视频");
        signUpButton.getStyleClass().setAll("btn","btn-info");
        signUpButton.setOnAction(e -> upLoadVideo(LocalDateTime.now(),HelloApplication.user.getSchoolNumber(),id));
        Button exitButton = new Button("上传个人总结");
        exitButton.getStyleClass().setAll("btn","btn-primary");
        exitButton.setOnAction(e -> upLoadSummary(LocalDateTime.now(),HelloApplication.user.getSchoolNumber(),id));

        card.getChildren().setAll(nameLabel,dateLabel,startTimeLabel,durationLabel,locationLabel,signUpButton,exitButton);

        return card;
    }
    private void upLoadSummary(LocalDateTime dateTime,String schoolID,int activityID){
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PDF Files","*.pdf"));
        File selectedFile = fileChooser.showOpenDialog(null);

        if (selectedFile != null) {
            try {
                // 复制文件到项目文件夹
                String fileName = selectedFile.getName();
                Path destination = Path.of(PROJECT_FOLDER+"\\pdf", fileName);
                Files.copy(selectedFile.toPath(), destination, StandardCopyOption.REPLACE_EXISTING);

                // 相对路径
                String relativePath = destination.toString();  // 相对路径为项目文件夹下的文件名
                // 将文件名称存储到数据库中
                enrollmentDAO.insertSummary(userDAO.schoolIDToID(schoolID),fileName,activityID);

                System.out.println("文件上传成功：" + relativePath);
            } catch (IOException e) {
                System.out.println("文件上传失败：" + e.getMessage());
            }
        }
    }
    private void upLoadVideo(LocalDateTime dateTime,String schoolID,int activityID){
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("VIDEO Files","*.mp4"));
        File selectedFile = fileChooser.showOpenDialog(null);

        if (selectedFile != null) {
            try {
                // 复制文件到项目文件夹
                String fileName = selectedFile.getName();
                Path destination = Path.of(PROJECT_FOLDER+"\\video", fileName);
                Files.copy(selectedFile.toPath(), destination, StandardCopyOption.REPLACE_EXISTING);

                // 相对路径
                String relativePath = destination.toString();  // 相对路径为项目文件夹下的文件名
                // 将文件名称存储到数据库中
                enrollmentDAO.insertVideo(userDAO.schoolIDToID(schoolID),fileName,activityID);

                System.out.println("文件上传成功：" + relativePath);
            } catch (IOException e) {
                System.out.println("文件上传失败：" + e.getMessage());
            }
        }
    }

}
