package com.example.demo1.DBengine;

import com.example.demo1.model.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MangerDAO {
    private String DBurl = DBConfig.getDbUrl();
    private String DBuser = DBConfig.getUsername();
    private String DBpassword = DBConfig.getPassword();

    public String findpdf(int activity_id, int student_id) {
        try (Connection connection = DriverManager.getConnection(DBurl, DBuser, DBpassword);
                PreparedStatement statement = connection.prepareStatement(
                        "SELECT enroll_summary FROM enrollment WHERE enroll_activity=? AND enroll_user=?")) {
            statement.setInt(1, activity_id);
            statement.setInt(2, student_id);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    String enrollSummary = resultSet.getString("enroll_summary");
                    return enrollSummary;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return "0";
    }

    public String findvideo(int activity_id, int student_id) {
        try (Connection connection = DriverManager.getConnection(DBurl, DBuser, DBpassword);
                PreparedStatement statement = connection.prepareStatement(
                        "SELECT enroll_video FROM enrollment WHERE enroll_activity=? AND enroll_user=?")) {
            statement.setInt(1, activity_id);
            statement.setInt(2, student_id);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    String enrollSummary = resultSet.getString("enroll_video");
                    return enrollSummary;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return "0";
    }

    public String findfin(int activity_id, int student_id) {
        try (Connection connection = DriverManager.getConnection(DBurl, DBuser, DBpassword);
                PreparedStatement statement = connection.prepareStatement(
                        "SELECT enroll_finstatus FROM enrollment WHERE enroll_activity=? AND enroll_user=?")) {
            statement.setInt(1, activity_id);
            statement.setInt(2, student_id);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    String enrollSummary = resultSet.getString("enroll_finstatus");
                    return enrollSummary;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return "0";
    }

    public String findstate(int activity_id, int student_id) {
        try (Connection connection = DriverManager.getConnection(DBurl, DBuser, DBpassword);
                PreparedStatement statement = connection.prepareStatement(
                        "SELECT enroll_status FROM enrollment WHERE enroll_activity=? AND enroll_user=?")) {
            statement.setInt(1, activity_id);
            statement.setInt(2, student_id);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    String enrollSummary = resultSet.getString("enroll_status");
                    return enrollSummary;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return "0";
    }

    public List<Map<String, Object>> findUsers() {
        List<Map<String, Object>> userList = new ArrayList<>();

        try (Connection connection = DriverManager.getConnection(DBurl, DBuser, DBpassword);
                PreparedStatement statement = connection.prepareStatement(
                        "SELECT user_name, user_schoolNumber, user_color FROM user WHERE user_identity=?")) {
            statement.setString(1, "志愿者");
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    Map<String, Object> userMap = new HashMap<>();
                    userMap.put("user_name", resultSet.getString("user_name"));
                    userMap.put("user_schoolNumber", resultSet.getString("user_schoolNumber"));
                    String s = resultSet.getString("user_color");
                    if (s == null)
                        userMap.put("user_color", "未设置名单");

                    else if (s.equals("red"))
                        userMap.put("user_color", "红名单");
                    else if (s.equals("black"))
                        userMap.put("user_color", "黑名单");
                    else
                        userMap.put("user_color", "未设置名单");

                    userList.add(userMap);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return userList;
    }

    public void updateFinStatus(int activity_id, int student_id, String status) {
        try (Connection connection = DriverManager.getConnection(DBurl, DBuser, DBpassword);
                PreparedStatement statement = connection.prepareStatement(
                        "UPDATE enrollment SET enroll_finstatus=? WHERE enroll_activity=? AND enroll_user=?")) {
            statement.setString(1, status);
            statement.setInt(2, activity_id);
            statement.setInt(3, student_id);

            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("状态更新成功");
            } else {
                System.out.println("状态更新失败");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateColor(String schoolNumber, String color) {
        try (Connection connection = DriverManager.getConnection(DBurl, DBuser, DBpassword);
                PreparedStatement statement = connection.prepareStatement(
                        "UPDATE user SET user_color=? WHERE user_schoolNumber=?")) {

            statement.setString(1, color);
            statement.setString(2, schoolNumber);

            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("状态更新成功");
            } else {
                System.out.println("状态更新失败");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void delact(int activityId) {
        try (Connection connection = DriverManager.getConnection(DBurl, DBuser, DBpassword);
                PreparedStatement statement = connection.prepareStatement(
                        "DELETE from activity where activity_id=?")) {

            statement.setInt(1, activityId);

            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("状态更新成功");
            } else {
                System.out.println("状态更新失败");
            }
        } catch (

        SQLException e) {
            e.printStackTrace();
        }
    }

}
