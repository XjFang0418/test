package com.example.demo1.view;
import com.example.demo1.DBengine.*;
import com.example.demo1.HelloApplication;
import com.example.demo1.model.Manager;
import com.example.demo1.model.Volunteer;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;

import org.kordamp.bootstrapfx.scene.layout.Panel;

import java.sql.*;

public class LoginView {
    UserDAO userDAO=new UserDAO();

    public Panel createLoginPanel() {
        Panel panel = new Panel("登录");
        panel.getStyleClass().add("panel-primary");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20));

        Label schoolIDLabel = new Label("学工号");
        TextField schoolIDField = new TextField();
        Label passwordLabel = new Label("密码：");
        PasswordField passwordField = new PasswordField();
        Button loginButton = new Button("登录");
        Label tip=new Label("没有账号？");
        Label info=new Label("");
        Button registerButton=new Button("去注册");
        CheckBox showPasswordCheckBox = new CheckBox("显示密码");
        loginButton.getStyleClass().setAll("btn","btn-success");
        registerButton.getStyleClass().setAll("btn","btn-primary");


        grid.add(schoolIDLabel, 0, 0);
        grid.add(schoolIDField, 1, 0);
        grid.add(passwordLabel, 0, 1);
        grid.add(passwordField, 1, 1);
        grid.add(showPasswordCheckBox,1,2);
        grid.add(loginButton, 1, 3);
        grid.add(tip,0,4);
        grid.add(registerButton,1,4);
        grid.add(info,0,3);

        panel.setBody(grid);
        showPasswordCheckBox.selectedProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue) {
                // 显示明文密码
                passwordField.setPromptText(passwordField.getText());
                passwordField.clear();
            } else {
                // 隐藏明文密码，恢复为密码输入框
                passwordField.setText(passwordField.getPromptText());
                passwordField.setPromptText(null);
            }
        });
        loginButton.setOnAction(actionEvent -> {
            String schoolID = schoolIDField.getText();
            String password = passwordField.getText();
            int loginResult=userDAO.login(schoolID,password);

            if(loginResult==0) {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Login Success");
                alert.setHeaderText(null);
                alert.setContentText("Successfully Login");
                alert.showAndWait();
                String identity=userDAO.schoolIDToIdentity(schoolID);

                if(identity.equals("志愿者")){
                    HelloApplication.user=new Volunteer();
                    HelloApplication.user.setSchoolNumber(schoolID);
                    HelloApplication.changeLoginToHomepage();;
                }
                else
                {
                    HelloApplication.user=new Manager();
                    HelloApplication.user.setSchoolNumber(schoolID);
                    HelloApplication.changeLoginToManagerHomePage();
                }



                // 关闭当前登录界面

            }
            else if(loginResult==1){
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Login Failed");
                alert.setHeaderText(null);
                alert.setContentText("Invalid username or password. Please try again.");
                alert.showAndWait();
            }
            else{
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Login Failed");
                alert.setHeaderText(null);
                alert.setContentText("unknown SQL interrupt");
                alert.showAndWait();
            }

        });
        registerButton.setOnAction(actionEvent -> {
            HelloApplication.changeLoginToRegister();
        });
        return panel;
    }
}
