package com.example.demo1.model;
public class Volunteer extends User{

}