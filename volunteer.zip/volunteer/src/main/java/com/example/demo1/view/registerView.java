package com.example.demo1.view;
import com.example.demo1.DBengine.*;
import com.example.demo1.HelloApplication;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import org.kordamp.bootstrapfx.scene.layout.Panel;

public class registerView {
    UserDAO userDAO=new UserDAO();

    public Panel createRegisterPanel() {
        Panel panel = new Panel("注册");
        panel.getStyleClass().add("panel-success");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20));

        Label schoolNumberLabel = new Label("学工号");
        TextField schoolNumberField = new TextField();
        Label nameLabel=new Label("姓名");
        TextField nameField=new TextField();
        Label passwordLabel = new Label("密码");
        PasswordField passwordField = new PasswordField();
        Label roleLabel=new Label("身份");
        ComboBox<String> roleComboBox = new ComboBox<>(FXCollections.observableArrayList("管理员", "志愿者"));
        roleComboBox.setPromptText("请选择角色");
        Button registerButton = new Button("注册");
        Label tip=new Label("");
        Label info=new Label("已经有账号");
        Button loginButton=new Button("去登录");
        loginButton.getStyleClass().setAll("btn","btn-success");
        registerButton.getStyleClass().setAll("btn","btn-primary");
        CheckBox showPasswordCheckBox = new CheckBox("显示密码");


        grid.add(schoolNumberLabel, 0, 0);
        grid.add(schoolNumberField, 1, 0);
        grid.add(passwordLabel, 0, 1);
        grid.add(passwordField, 1, 1);
        grid.add(showPasswordCheckBox,1,2);
        grid.add(nameLabel,0,3);
        grid.add(nameField,1,3);
        grid.add(roleLabel,0,4);
        grid.add(roleComboBox,1,4);

        grid.add(registerButton, 1, 5);
        grid.add(tip,0,5);
        grid.add(info,0,6);
        grid.add(loginButton,1,6);



        panel.setBody(grid);
        loginButton.setOnAction(event->{
            HelloApplication.changeRegisterToLogin();
        });
        showPasswordCheckBox.selectedProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue) {
                // 显示明文密码
                passwordField.setPromptText(passwordField.getText());
                passwordField.clear();
            } else {
                // 隐藏明文密码，恢复为密码输入框
                passwordField.setText(passwordField.getPromptText());
                passwordField.setPromptText(null);
            }
        });
        registerButton.setOnAction(event -> {
            String studentID=schoolNumberField.getText();
            String username = nameField.getText();
            String password = passwordField.getText();
            String selectedRole = roleComboBox.getValue();
            int registerResult=userDAO.register(studentID,username,password,selectedRole);
            if(registerResult==0){
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Registration Successful");
                alert.setHeaderText(null);
                alert.setContentText("Congratulations! You have successfully registered.");
                alert.showAndWait();
                if(alert.getResult().getText().equals("确定")) {
                    HelloApplication.changeRegisterToLogin();
                }
            }
            else if(registerResult==1){
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Registration Failed");
                alert.setHeaderText(null);
                alert.setContentText("您的学号已经注册过,请直接登录");
                alert.showAndWait();
                if(alert.getResult().getText().equals("确定")) {
                    schoolNumberField.setText("");
                }
            }
            else if(registerResult==2){
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Registration Failed");
                alert.setHeaderText(null);
                alert.setContentText("密码位数需要大于等于6，请重新输入");
                alert.showAndWait();
                if(alert.getResult().getText().equals("确定")) {
                    passwordField.setText("");
                }
            }
            else if(registerResult==3){
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Registration Failed");
                alert.setHeaderText(null);
                alert.setContentText("未知错误，数据库操作失败");
                alert.showAndWait();
            }

        });
        return panel;
    }
}
