package com.example.demo1.view;

import com.example.demo1.model.*;
import com.example.demo1.DBengine.*;
import com.example.demo1.HelloApplication;
import javafx.collections.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.kordamp.bootstrapfx.scene.layout.Panel;

import java.io.File;
import java.sql.*;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.example.demo1.function.*;

public class mangerHomeView {
    final private String DBurl = DBConfig.getDbUrl();
    final private String DBuser = DBConfig.getUsername();
    final private String DBpassword = DBConfig.getPassword();
    final private ActivityDAO activityDAO = new ActivityDAO();
    final private MangerDAO mangerDAO = new MangerDAO();

    private Panel panel;
    private BorderPane root;

    private TextField fileTextField;
    final private VBox sidebar = new VBox();
    private final Allact allact = new Allact();
    private FlowPane page2Content; // Moved as a class member variable
    private ObservableList<Activity> activities;

    public Panel createManagerHomePanel() {
        panel = new Panel("管理员主页");
        panel.getStyleClass().add("panel-info");

        sidebar.getStyleClass().add("menu-bar");
        sidebar.setPrefHeight(500);
        Button publishActivityButton = new Button("发布活动");
        publishActivityButton.getStyleClass().setAll("sidebar-button");
        publishActivityButton.setOnAction(e -> switchToPublishActivityPage());
        Button activityDisplayButton = new Button("所有活动");
        activityDisplayButton.getStyleClass().setAll("sidebar-button");
        activityDisplayButton.setOnAction(e -> switchToActivitiesPage());
        Button finishedActivityButton = new Button("人员名单");
        finishedActivityButton.getStyleClass().setAll("sidebar-button");
        finishedActivityButton.setOnAction(e -> switchToMember());
        Button logoutButton = new Button("注销");
        logoutButton.getStyleClass().setAll("sidebar-logout-button");
        logoutButton.setOnAction(actionEvent -> HelloApplication.changeManagerHomepageToLogin());

        sidebar.getChildren().addAll(activityDisplayButton, publishActivityButton, finishedActivityButton,
                logoutButton);
        root = new BorderPane();
        root.setLeft(sidebar);

        panel.setBody(root);
        switchToActivitiesPage();
        return panel;
    }

    private void switchToActivitiesPage() {
        System.out.println(page2Content);
        if (page2Content == null) {
            page2Content = new FlowPane();
            page2Content.setPadding(new Insets(10));
            page2Content.setAlignment(Pos.CENTER);
            root.setCenter(page2Content);
        } else {
            page2Content.getChildren().clear(); // Clear existing content
        }

        activities = generateSampleData();
        TextField searchField = new TextField();
        Button searchButton = new Button("搜索");
        searchButton.getStyleClass().addAll("btn","btn-info");
        TableView<Activity> tableView = new TableView<>();

        Tooltip tooltip = new Tooltip("双击即可进入对应活动");

        // 将Tooltip绑定到TableView上
        Tooltip.install(tableView, tooltip);
        tableView.setMinHeight(300);
        tableView.setMaxWidth(350);
        tableView.setOnMouseClicked(event -> {
            if (event.getClickCount() == 2) { // 检查是否是双击事件
                Activity selectedActivity = tableView.getSelectionModel().getSelectedItem();
                if (selectedActivity != null) {
                    switchToModifyActivityPage(Integer.parseInt(selectedActivity.getId()));
                }

            }
        });
        tableView.getStyleClass().add("header");
        // 设置表的行样式
        tableView.setRowFactory(tv -> {
            TableRow<Activity> row = new TableRow<>();
            row.getStyleClass().add("row");

            // 设置奇数行和偶数行的颜色
            if (row.getIndex() % 2 == 0) {
                row.getStyleClass().add("even");
            } else {
                row.getStyleClass().add("odd");
            }

            return row;
        });
        TableColumn<Activity, String> nameColumn = new TableColumn<>("名称");
        TableColumn<Activity, String> dateColumn = new TableColumn<>("日期");
        TableColumn<Activity, String> locationColumn = new TableColumn<>("地点");
        TableColumn<Activity, String> leaderColumn = new TableColumn<>("发布人");
        TableColumn<Activity, String> statusColumn = new TableColumn<>("状态");
        statusColumn.setPrefWidth(120);
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("date"));
        locationColumn.setCellValueFactory(new PropertyValueFactory<>("location"));
        leaderColumn.setCellValueFactory(new PropertyValueFactory<>("leader"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
        tableView.getColumns().addAll(nameColumn, dateColumn, locationColumn, leaderColumn, statusColumn);

        tableView.setItems(activities);

        VBox sall = new VBox(10, searchField, searchButton, tableView);
        sall.setPadding(new Insets(10));

        searchButton.setOnAction(event -> {
            String keyword = searchField.getText().trim();
            ObservableList<Activity> searchResults = searchActivities(keyword);
            tableView.setItems(searchResults);
        });
        page2Content.getChildren().addAll(sall);
        page2Content.setAlignment(Pos.CENTER);
        page2Content.getStyleClass().add("custom-pane");
        // 在根布局中切换页面
        root.setCenter(page2Content);

    }

    private ObservableList<Activity> generateSampleData() {
        ObservableList<Activity> data = FXCollections.observableArrayList();
        String query = "SELECT activity_id,activity_status,activity_date,activity_name,activity_place,user_name FROM activity JOIN user ON activity.activity_applicat=user.user_id ";

        try (Connection connection = DriverManager.getConnection(DBurl, DBuser, DBpassword);
                Statement statement = connection.createStatement();

                ResultSet resultSet = statement.executeQuery(query)) {

            while (resultSet.next()) {
                String activityId = resultSet.getString("activity_id");
                String activityName = resultSet.getString("activity_name");

                String activityLocation = resultSet.getString("activity_place");
                String activityDate = resultSet.getString("activity_date");
                String activityStatus = resultSet.getString("activity_status");
                String activityLeader = resultSet.getString("user_name");
                data.add(new Activity(activityId, activityName, activityDate, activityLocation, activityLeader,
                        activityStatus));

            }
        } catch (SQLException e) {
            e.printStackTrace();
            // 处理异常
        }

        System.out.println(data);
        return data;
    }

    private ObservableList<Activity> searchActivities(String keyword) {
        ObservableList<Activity> results = FXCollections.observableArrayList();
        for (Activity activity : activities) {
            if (activity.getName().contains(keyword) ||
                    activity.getDate().contains(keyword) ||
                    activity.getLocation().contains(keyword)
                    ||
                    activity.getLeader().contains(keyword)
                    ||
                    activity.getStatus().contains(keyword)) {
                results.add(activity);
            }
        }
        return results;
    }

    private void switchToPublishActivityPage() {
        // 创建发布活动页面的布局
        VBox page1Content = new VBox();
        page1Content.getStyleClass().add("page-content");
        // 创建发布活动页面的内容
        GridPane form = new GridPane();
        form.setHgap(10);
        form.setVgap(10);
        Label nameLabel = new Label("活动名称");
        TextField nameField = new TextField();
        form.addRow(0, nameLabel, nameField);
        // 活动时间
        Label dateLabel = new Label("活动日期:");
        DatePicker datePicker = new DatePicker();
        form.addRow(1, dateLabel, datePicker);
        Label startTimeLabel = new Label("开始时间:");
        ComboBox<Integer> startComboBox = new ComboBox<>();
        startComboBox.setItems(FXCollections.observableArrayList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16,
                17, 18, 19, 20, 21, 22, 23, 24));
        startComboBox.setPromptText("开始时间");

        Label endTimeLabel = new Label("结束时间:");
        ComboBox<Integer> endComboBox = new ComboBox<>();
        endComboBox.setItems(FXCollections.observableArrayList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16,
                17, 18, 19, 20, 21, 22, 23, 24));
        endComboBox.setPromptText("结束时间");
        form.addRow(2, startTimeLabel, startComboBox);
        form.addRow(3, endTimeLabel, endComboBox);
        // 活动地点
        Label locationLabel = new Label("活动地点:");
        TextField locationTextField = new TextField();
        form.addRow(4, locationLabel, locationTextField);

        // 申请人
        Label applicantLabel = new Label("申请人学号:");
        TextField applicantTextField = new TextField();
        form.addRow(5, applicantLabel, applicantTextField);

        // 活动策划书
        Label fileLabel = new Label("活动策划书:");
        fileTextField = new TextField();

        // fileTextField.setDisable(true);
        Button uploadButton = new Button("上传");
        uploadButton.setOnAction(e -> selectFile());
        form.addRow(6, fileLabel, fileTextField, uploadButton);

        // 提交按钮
        Button submitButton = new Button("提交");

        submitButton.setOnAction(e -> {
            LocalDate date = datePicker.getValue();
            int startTime = startComboBox.getValue();
            int endTime = endComboBox.getValue();
            String location = locationTextField.getText();
            String applicant = applicantTextField.getText();
            String file = fileTextField.getText();
            String name = nameField.getText();
            submitForm(name, date, startTime, endTime, location, applicant, file);
        });

        HBox buttonBox = new HBox(submitButton);
        buttonBox.setSpacing(10);
        form.setAlignment(Pos.CENTER);
        buttonBox.setAlignment(Pos.CENTER);
        page1Content.getChildren().addAll(form, buttonBox);
        page1Content.setAlignment(Pos.CENTER);
        page1Content.getStyleClass().add("custom-pane");
        // 在根布局中切换页面
        root.setCenter(page1Content);
    }

    private void switchToMember() {
        if (page2Content != null)
            page2Content.getChildren().clear();

        List<Map<String, Object>> userList;
        userList = mangerDAO.findUsers();

        VBox vbox = new VBox(); // 使用VBox作为容器
        vbox.setPrefWidth(350);
        Label title=new Label("姓名\t\t学号\t\t\t设置");

        HBox titleBox = new HBox(title);
        HBox.setHgrow(new Region(), Priority.ALWAYS);
        titleBox.setAlignment(Pos.CENTER_LEFT);
        vbox.getChildren().add(titleBox); // 将标签添加到VBox中
        vbox.setSpacing(5);
        for (Map<String, Object> userMap : userList) {
            String userName = (String) userMap.get("user_name");
            String userSchoolNumber = (String) userMap.get("user_schoolNumber");
            String userColor = (String) userMap.get("user_color");
            System.out.println(userColor);

            Label label = new Label(userName + "\t" + userSchoolNumber + "\t" + userColor+"\t");
            Button inred = new Button("red");
            inred.setOnAction(e -> {
                mangerDAO.updateColor(userSchoolNumber, "red");
                switchToMember();

            });
            inred.getStyleClass().addAll("red-button");

            Button inblack = new Button("black");
            inblack.setOnAction(e -> {
                mangerDAO.updateColor(userSchoolNumber, "black");
                switchToMember();
            });
            inblack.getStyleClass().addAll("black-button");

            Button out = new Button("out");
            out.setOnAction(e -> {
                mangerDAO.updateColor(userSchoolNumber, "notIn");
                switchToMember();

            });
            out.getStyleClass().addAll("blue-button");
            HBox hbox = new HBox(label, new Region(), inred, inblack, out);
            HBox.setHgrow(new Region(), Priority.ALWAYS);
            hbox.setAlignment(Pos.CENTER_LEFT);
            hbox.setSpacing(5);
            vbox.getChildren().add(hbox); // 将标签添加到VBox中
        }

        ScrollPane scrollPane = new ScrollPane(vbox);
        scrollPane.setPrefHeight(400); // 将VBox放置在ScrollPane中
        scrollPane.setStyle("-fx-padding: 10px");
        scrollPane.setFitToWidth(true);

        page2Content.getChildren().add(scrollPane); // 将ScrollPane添加到page2Content中

        page2Content.setAlignment(Pos.TOP_CENTER);
        // 在根布局中切换页面
        root.setCenter(page2Content);
    }

    private void selectFile() {
        File selectedFile;
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("PDF Files", "*.pdf"));
        Stage stage = (Stage) panel.getScene().getWindow();
        selectedFile = fileChooser.showOpenDialog(stage);
        if (selectedFile != null) {
            String filePath = selectedFile.getAbsolutePath();
            fileTextField.setText(filePath);
        }
    }

    private void submitForm(String name, LocalDate date, int startTime, int endTime, String location, String applicant,
            String file) {
        int submitResult = activityDAO.publishActivity(name, date, startTime, endTime, location, applicant, file);
        if (submitResult == 0) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Submit Successful");
            alert.setHeaderText(null);
            alert.setContentText(
                    "Congratulations! You have successfully submit your activity.Please wait for the approvement");
            alert.showAndWait();
            if (alert.getResult().getText().equals("确定")) {
                switchToActivitiesPage();
            }
        } else if (submitResult == 1) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Submit Failed");
            alert.setHeaderText(null);
            alert.setContentText("The end time must be bigger than the start time!");
            alert.showAndWait();
        } else if (submitResult == 2) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Submit Failed");
            alert.setHeaderText(null);
            alert.setContentText("The mandatory field is blank, please check");
            alert.showAndWait();
        } else if (submitResult == 4) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Submit Failed");
            alert.setHeaderText(null);
            alert.setContentText("Your schoolID didn't exist,please check again");
            alert.showAndWait();
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Submit Failed");
            alert.setHeaderText(null);
            alert.setContentText("Unknown sql error");
            alert.showAndWait();
        }

    }

    private void switchToModifyActivityPage(int activityID) {
        // 创建修改活动页面的布局
        VBox pageContent = new VBox();
        pageContent.getStyleClass().add("page-content");

        // 创建表单控件
        GridPane form = new GridPane();
        form.setHgap(10);
        form.setVgap(10);

        // 从数据库中获取活动的属性值
        String query = "SELECT activity_name, activity_date, activity_startTime, activity_duration, activity_place, activity_applicat, activity_file,activity_status FROM activity WHERE activity_id = ?";
        try (Connection connection = DriverManager.getConnection(DBurl, DBuser, DBpassword);
                PreparedStatement statement = connection.prepareStatement(query)) {

            // 设置查询参数
            statement.setInt(1, activityID);

            // 执行查询并获取结果集
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                // 提取结果集中的属性值
                String name = resultSet.getString("activity_name");
                LocalDate date = resultSet.getDate("activity_date").toLocalDate();
                int startTime = resultSet.getInt("activity_startTime");
                int endTime = startTime + resultSet.getInt("activity_duration");
                String location = resultSet.getString("activity_place");
                int applicant = resultSet.getInt("activity_applicat");
                String file = resultSet.getString("activity_file");
                String status = resultSet.getString("activity_status");
                // 创建表单控件
                // 活动名称
                Label nameLabel = new Label("活动名称");
                TextField nameField = new TextField(name);
                form.addRow(0, nameLabel, nameField);

                // 活动日期
                Label dateLabel = new Label("活动日期:");
                DatePicker datePicker = new DatePicker(date);
                form.addRow(1, dateLabel, datePicker);

                // 开始时间
                Label startTimeLabel = new Label("开始时间:");
                ComboBox<Integer> startComboBox = new ComboBox<>();
                startComboBox.setItems(FXCollections.observableArrayList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14,
                        15, 16, 17, 18, 19, 20, 21, 22, 23, 24));
                startComboBox.setValue(startTime);
                form.addRow(2, startTimeLabel, startComboBox);

                // 结束时间
                Label endTimeLabel = new Label("结束时间:");
                ComboBox<Integer> endComboBox = new ComboBox<>();
                endComboBox.setItems(FXCollections.observableArrayList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14,
                        15, 16, 17, 18, 19, 20, 21, 22, 23, 24));
                endComboBox.setValue(endTime);
                form.addRow(3, endTimeLabel, endComboBox);

                // 活动地点
                Label locationLabel = new Label("活动地点:");
                TextField locationTextField = new TextField(location);
                form.addRow(4, locationLabel, locationTextField);

                // 申请人
                Label applicantLabel = new Label("申请人学号:");
                TextField applicantTextField = new TextField(String.valueOf(applicant));
                form.addRow(5, applicantLabel, applicantTextField);

                // 活动策划书
                Label fileLabel = new Label("活动策划书:");
                fileTextField = new TextField(file);
                form.addRow(6,fileLabel,fileTextField);


                Button uploadButton = new Button("上传");
                uploadButton.getStyleClass().addAll("btn","btn-info");
                Button viewButton = new Button("查看");
                viewButton.getStyleClass().addAll("btn","btn-info");
                viewButton.setOnAction(e -> allact.viewPDF(activityID, 0));
                Label nopdf = new Label("未上传");
                uploadButton.setOnAction(e -> selectFile());
                if (!file.equals(""))
                    form.addRow(7, uploadButton, viewButton);
                else
                    form.addRow(7,  uploadButton, nopdf);
                Label statusl = new Label(status);
                Label statusLabel=new Label("活动状态：");
                form.addRow(8,statusLabel,statusl);
                // 返回按钮
                Button backButton = new Button("返回");
                backButton.getStyleClass().addAll("btn");
                backButton.setOnAction(e -> switchToActivitiesPage());
                HBox backButtonBox = new HBox(backButton);
                backButtonBox.setAlignment(Pos.TOP_RIGHT);
                pageContent.getChildren().add(backButtonBox);

                // 提交按钮
                Button submitButton = new Button("提交修改");
                submitButton.getStyleClass().addAll("btn","btn-primary");
                submitButton.setOnAction(e -> {
                    // 获取用户修改后的数据
                    String newName = nameField.getText();
                    LocalDate newDate = datePicker.getValue();
                    int newStartTime = startComboBox.getValue();
                    int newEndTime = endComboBox.getValue();
                    String newLocation = locationTextField.getText();
                    String newApplicant = applicantTextField.getText();
                    String newFile = fileTextField.getText();

                    // 执行更新操作
                    int success = activityDAO.updateActivity(activityID, newName, newDate, newStartTime, newEndTime,
                            newLocation, newApplicant, newFile);

                    if (success == 0) {
                        // 更新成功
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("更新成功");
                        alert.setHeaderText(null);
                        alert.setContentText("活动信息已成功更新。");
                        alert.showAndWait();
                    } else {
                        // 更新失败
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("更新失败");
                        alert.setHeaderText(null);
                        alert.setContentText("活动信息更新失败，请重试。");
                        alert.showAndWait();
                    }
                });

                Button passButton = new Button("通过");
                passButton.getStyleClass().addAll("btn","btn-primary");
                Button banButton = new Button("驳回");
                passButton.getStyleClass().addAll("btn","btn-warning");
                Button memberList = new Button("志愿者名单");
                memberList.getStyleClass().addAll("btn","btn-info");
                Button delButton = new Button("删除活动");
                delButton.getStyleClass().addAll("btn","btn-danger");
                delButton.setOnAction(e -> {
                    Alert alert = new Alert(AlertType.CONFIRMATION);
                    alert.setTitle("彻底删除活动");
                    alert.setHeaderText("你正在尝试彻底删除活动信息");
                    alert.setContentText("尽管不能复原，依然确定删除?");

                    Optional<ButtonType> result = alert.showAndWait();
                    if (result.get() == ButtonType.OK) {
                        mangerDAO.delact(activityID);
                        switchToActivitiesPage();
                    }
                });
                passButton.setOnAction(e -> {
                    activityDAO.updateActivityStatus(activityID, "审批通过");
                    switchToModifyActivityPage(activityID);
                });
                memberList.setOnAction(e -> allact.showstudents(activityID));
                banButton.setOnAction(e -> {
                    activityDAO.updateActivityStatus(activityID, "审批驳回");
                    switchToModifyActivityPage(activityID);
                });

                HBox buttonBox = new HBox();
                if (!(status.equals("已结束") || status.equals("审批驳回")))
                {
                    buttonBox.getChildren().add(submitButton);

                    statusl.setTextFill(Color.DARKGRAY); // 设置字体颜色为灰色
                }



                if (status.equals("待审批")) {
                    buttonBox.getChildren().add(passButton);
                    buttonBox.getChildren().add(banButton);
                    statusl.setTextFill(Color.GREEN); // 设置字体颜色为绿色
                }
                if (!status.equals("审批驳回"))
                {
                    buttonBox.getChildren().add(memberList);
                    statusl.setTextFill(Color.DARKRED); // 设置字体颜色为绿色
                }

                buttonBox.getChildren().add(delButton);
                buttonBox.setSpacing(10);

                form.setAlignment(Pos.CENTER);
                buttonBox.setAlignment(Pos.CENTER);
                pageContent.setSpacing(10);
                pageContent.getChildren().addAll(form, buttonBox);
                pageContent.setAlignment(Pos.CENTER);

                // 在根布局中切换页面
                root.setCenter(pageContent);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // 处理异常
        }
    }

}
