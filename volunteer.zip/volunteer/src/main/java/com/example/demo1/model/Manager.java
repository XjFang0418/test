package com.example.demo1.model;

public class Manager extends User{
}
